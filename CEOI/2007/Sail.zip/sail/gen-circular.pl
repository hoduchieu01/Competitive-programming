#!/usr/bin/perl -w
use strict;

# 1x s bodem uvnitr
# 1x s trojuhelnikem uvnitr

require("gen-util.pl");

my $x = 10000;
my $y = 10000;
my $xC = 3478;
my $yC = 7690;

my @triangles;

my @parts = randomPartition($y, 50);

for my $part(@parts) {
	push @triangles, [0, $$part[1], 0, $$part[0] + $$part[1], $xC, $yC];
}
@parts = randomPartition($y, 50);
for my $part(@parts) {
	push @triangles, [$xC, $yC, $x, $$part[1], $x, $$part[0] + $$part[1], $xC, $yC];
}
@parts = randomPartition($x, 50);
for my $part(@parts) {
	push @triangles, [$$part[1], 0, $$part[0] + $$part[1], 0, $xC, $yC];
}
@parts = randomPartition($x, 50);
for my $part(@parts) {
	push @triangles, [$$part[1], $y, $$part[0] + $$part[1], $y, $xC, $yC];
}


outputSail("04", $x,$y,\@triangles, 0);

sub isSame {
	my ($cmpVal, $opts) = @_;

	for my $val(@$opts) {
		return 1 if $val == $cmpVal;
	}

	return 0;
}

sub createWithTriangle {
	my $x = 100000;
	my $y = 100000;
	my ($xC1, $yC1) = (36723, 11233);
	my ($xC2, $yC2) = (63451, 11234);
	my ($xC3, $yC3) = (53622, 92323);
	# The picture:
	# y+--------------------------------+
	#  |                                |
	#  |              3                 |
	#  |                                |
	#  |                                |
	#  |                      2         |
	#  |      1                         |
	#  |                                |
	# 0+--------------------------------+
	#  0                                x 

    my $sideParts = 50;
	my @triangles;

	push @triangles, [$xC1, $yC1, $xC2, $yC2, $xC3, $yC3];

	# left side
	my @parts = randomPartition($y, $sideParts);
	my $idx = @parts / 2 + int(rand(@parts / 2));
	for my $part(@parts[0..$idx-1]) {
		return &createWithTriangle if (isSame($yC1, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [0, $$part[1], 0, $$part[0] + $$part[1],$xC1, $yC1];
	}
	push @triangles, [$xC1,$yC1, 0, $parts[$idx][1], $xC3,$yC3];
	for my $part(@parts[$idx..$#parts]) {
		return &createWithTriangle if (isSame($yC3, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [0, $$part[1], 0, $$part[0] + $$part[1],$xC3, $yC3];
	}

	#top side
	@parts = randomPartition($x, $sideParts);
	for my $part(@parts) {
		return &createWithTriangle if (isSame($xC3, $part)); # make sure we do not create another edge with delta x	=0
		push @triangles, [$$part[1], $y, $$part[0] + $$part[1], $y, $xC3, $yC3];
	}

	# right side
	@parts = randomPartition($y, $sideParts);
	$idx = @parts / 2 + int(rand(@parts / 2));
	for my $part(@parts[0..$idx-1]) {
		return &createWithTriangle if (isSame($yC2, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [$x, $$part[1], $x, $$part[0] + $$part[1],$xC2, $yC2];
	}
	push @triangles, [$xC2,$yC2, $x, $parts[$idx][1], $xC3,$yC3];
	for my $part(@parts[$idx..$#parts]) {
		return &createWithTriangle if (isSame($yC3, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [$x, $$part[1], $x, $$part[0] + $$part[1],$xC3, $yC3];
	}

	# bottom side
	@parts = randomPartition($x, $sideParts);
	$idx = @parts / 2 + int(rand(@parts / 2));
	for my $part(@parts[0..$idx-1]) {
		return &createWithTriangle if (isSame($xC1, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [$$part[1], 0, $$part[0] + $$part[1], 0, $xC1, $yC1];
	}
	push @triangles, [$xC2,$yC2, $parts[$idx][1], 0, $xC1,$yC1];
	for my $part(@parts[$idx..$#parts]) {
		return &createWithTriangle if (isSame($xC2, $part)); # make sure we do not create another edge with delta y =0
		push @triangles, [$$part[1],0,  $$part[0] + $$part[1], 0,$xC2, $yC2];
	}

	outputSail("05", $x,$y,\@triangles, 0);
}


createWithTriangle();


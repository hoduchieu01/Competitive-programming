#!/usr/bin/perl -w
use strict;

require("gen-util.pl");

# 1-2 resitelne tuzkou a papirem
#  1x resitelne tuzkou a papirem, ale trojuhelniky zopakovane AxB krat


my $in0 = <<END_IN_0
6 10 5
4 0 12 4 4 5
4 5 12 4 14 5
0 3 10 3 4 5
4 5 10 3 8 7
7 7 7 10 5 11
0 1 2 0 2 2
END_IN_0
;

my $exp0 = <<END_EXP_0
0 0
0 5
0 0
4 2
10 0
8 4
END_EXP_0
;

open OUT, ">sail00.in" || die "open";
print OUT $in0;
close OUT || die "close";

open OUT, ">sail00.ex" || die "open";
print OUT $exp0;
close OUT || die "close";


my @triangles = (
	[0,0,5,0,2,2],
	[5,0,10,0,10,4],
	[2,2,5,0,10,5],
	[2,2,10,5,10,10],
	[0,0,3,3,0,6],
	[0,6,3,3,3,7],
	[0,6,3,7,0,7],
	[0,7,3,7,0,10],
	[3,3,3,7,5,5],
	[0,10,5,5,5,10],
	[5,5,10,10,5,10],
	[10,5,10,4,5,0]
);

outputSail("01", 10,10,\@triangles, 1);


@triangles = (
	#UL square
	[0, 20, 5, 20, 0, 15],
	[0,15, 5, 20, 10, 15],
	[5,20, 10,15, 10,20],
	[0,10, 0, 15,5,10],
	[0,15, 5,10,10,15],
	[5,10, 10, 10, 10, 15],
	# UR square
	[10, 20, 20, 20, 15, 15],
	[20,20, 15,15, 20, 10],
	[10,10,15, 15, 20, 10],
	[10,10, 15,15, 10,20],
	#BR square
	[10,10,20,10,15,5],
	[20, 0, 20,10, 15,5],
	[15,0, 20, 0, 15,5],
	[10,10,15,0, 15,5],
	[10,10,10,0,15,0],
	#BL square
	[0,0, 4,5,0,10],
	[0,10, 10,10, 4,5],
	[4,5,10, 0, 10,10],
	[0,0, 4,5,10,0]
);

outputSail("02", 20,20,\@triangles, 1);

# 8x8 repeated 8x8 square
my @src = (
	[0,0,2,2,8,0],
	[2,2,8,0,5,5],
	[0,0,2,2,0,8],
	[8,0,5,5,8,8],
	[2,2,4,4,0,8],
	[4,4,5,6,0,8],
	[5,6,6,8,0,8],
	[4,4,8,8,6,8]
);

@triangles = ();

for my $i (0 .. 7) {
	for my $j (0 .. 7) {
		for my $triangle(@src) {
			push @triangles, [
				$$triangle[0] + $i * 8, $$triangle[1] + $j * 8,
				$$triangle[2] + $i * 8, $$triangle[3] + $j * 8,
				$$triangle[4] + $i * 8, $$triangle[5] + $j * 8
			];
		}
	}
}


outputSail("03", 8*8,8*8,\@triangles, 1);


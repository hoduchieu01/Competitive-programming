
use strict;

sub shuffle {

	my @ary = map { [rand, $_] } @_;
	@ary = sort { $$a[0] <=> $$b[0] } @ary;
	return map {$$_[1]} @ary;
}


sub max {
	return undef unless @_;

	my $max = shift @_;
	map {$max = $_ if $_ > $max } @_;
	$max;
}

sub min {
	return undef unless @_;

	my $min = shift @_;
	map {$min = $_ if $_ < $min } @_;
	$min;
}


my $_maxCoord = 1000000000;

sub xrnd {
	my $doNotMove = shift @_;
	my $maxCoord = shift @_;

	if ($maxCoord > $_maxCoord) {
		$maxCoord = $_maxCoord;
	}

	my $min = -min(@_);
	my $max = $maxCoord - max(@_);

	return $min if $doNotMove;

	return $min if ($min >= $max);

	return $min + int (rand($max - $min));
}


sub outputSail {
	my($num, $x, $y, $triangles, $doNotMove) = @_;
	$triangles = [shuffle(@$triangles)];

	my $n = @$triangles;
	open OUT, ">sail$num.in" || die "open";
	print OUT "$n $x $y\n";


	for my $triangle(@$triangles) {
		my $xd = xrnd($doNotMove, $x * 2, @$triangle[0,2,4]);
		my $yd = xrnd($doNotMove, $y * 2, @$triangle[1,3,5]);
		print OUT ($$triangle[0] + $xd) . " " . ($$triangle[1] + $yd) 
		    . " " . ($$triangle[2] + $xd) . " " . ($$triangle[3] + $yd) 
			. " " . ($$triangle[4] + $xd) . " " . ($$triangle[5] + $yd) 
			. "\n";
	}
	close OUT || die "close";


	open OUT, ">sail$num.ex" || die "open";
	for my $triangle(@$triangles) {
		print OUT $$triangle[0] . " " . $$triangle[1] . "\n";
	}
	close OUT || die "close";
}


sub randomPartition {
	my ($width, $n) = @_;

	my $prob = (2*$width) / $n;

	my @try = map { 1 + int(rand ($prob))} 1..$n;
	my $sum = 0;
	map {$sum += $_} @try;

	while($sum > $width) {
		my $x = pop @try;
		$sum -= $x;
	}

	return randomPartition($width, $n) if $sum > 2*$width || $sum < $width/1.6;

	if ($sum < $width) {
		push @try, $width - $sum;
	}

	return randomPartition($width, $n) unless @try >= $n/2 && @try < 2*$n;

	my @out;
	$sum = 0;
	for my $n(@try) {
		push @out, [$n, $sum];
		$sum += $n;
	}

	return @out;
}

1;

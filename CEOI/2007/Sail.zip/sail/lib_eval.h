
#ifndef __LIB_EVAL_H_INCLUDED__
#define __LIB_EVAL_H_INCLUDED__

#define EPS 0.0000000000001

class Number {
	private:
		long double value;

	public:
		Number() : value(0) { }
		Number(int v) : value(v) { }
		Number(const Number &n) : value(n.value) {}

		Number operator+(const Number&b) { return Number(*this)+= b; }
		Number operator-(const Number&b) { return Number(*this)-= b; }
		Number operator*(const Number&b) { return Number(*this)*= b; }
		Number operator/(const Number&b) { return Number(*this)/= b; }

		bool operator!=(const Number &b) const { return !(*this == b); }
		bool operator<=(const Number &b) const { return b >= *this; }
		bool operator<(const Number &b) const { return b > *this; }
		bool operator>(const Number &b) const { return *this >= b && *this != b; }

		double getDouble() {return value; }
		Number& operator+=(const Number &b) {
			value += b.value;
			return *this;
		}

		Number& operator-=(const Number &b) {
			value -= b.value;
			return *this;
		}

		Number& operator*=(const Number &b) {
			value *= b.value;
			return *this;
		}

		Number& operator/=(const Number &b) {
			value /= b.value;
			return *this;
		}

		bool operator==(const Number &b) const {
			double d = value - b.value;
			return d > -EPS && d < EPS;
		}

		bool operator>=(const Number &b) const {
			double d = value - b.value;
			return d > -EPS;
		}

		Number& operator=(const Number &b) {
			value = b.value;
			return *this;
		}

};


class Point {
	public:
		Number x, y;
		Point(Number _x, Number _y) : x(_x), y(_y) {}
		Point(): x(0), y(0) {}

		bool operator==(const Point &p) const {
			return x == p.x && y == p.y;
		}
		bool operator!=(const Point &p) const {
			return !(*this == p);
		}
};


bool areColinear(Point* pts, int n);
// inside triangle or at boundary
bool isInTriangle(Point x, Point a, Point b, Point c);
int convexHull(Point* pts, int n, Point* hull);
// excluding endpoints
bool segmentsIntersectInside(Point a1, Point b1, Point a2, Point b2, Point &isection);
bool segmentsIntersect(Point a1, Point b1, Point a2, Point b2, Point &isection);
bool trianglesIntersectInside(Point a1, Point b1, Point c1, Point a2, Point b2, Point c2, Point &isection);
int trianglesIntersectInside2(Point a1, Point b1, Point c1, Point a2, Point b2, Point c2, Point *conflicts);
bool gauss(Number** matrix, int n, Number* output);



#endif

#!/usr/bin/perl -w
use strict;

# 1x "nahodna data"

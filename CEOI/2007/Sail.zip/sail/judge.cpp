#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include "lib_eval.h"

using namespace std;

#define MAX_TRIANGLES 10000

int N, X, Y;

Point triangles[MAX_TRIANGLES + 1][3];

void checkPoint(Point pt, int which3) {
	if (pt.x < 0 || pt.x > X || pt.y < 0 || pt.y > Y) {
		cout << 0 << endl << "Triangle #" << which3 << 
			" is not entirely inside the rectangle: (" << pt.x.getDouble()
		   << "," << pt.y.getDouble() << ")" << endl;
		cerr << "Not inside" << endl;
		exit(1);
	}
}

int main(int argc, char** argv) {
	if (argc != 3) {
		cerr << "invalid invocation" << endl;
		exit(1);
	}

	ifstream in(argv[1]); 
	ifstream out(argv[2]); 

	in >> N >> X >> Y;
	if (!in) {
		cerr << "invalid infile" << endl;
		exit(1);
	}

	Number areaCoveredByTriangles = 0;

	int i, x, y;
	for (i = 0; i < N; i++) {
		in >> x >> y; triangles[i][0] = Point(x, y);
		in >> x >> y; triangles[i][1] = Point(x, y);
		in >> x >> y; triangles[i][2] = Point(x, y);

		if (areColinear(triangles[i], 3)) {
			cerr << "BUG: Triangle #" << (i+1) << " is not a triangle" << endl;
			exit(1);
		}
		
		Number x1 = triangles[i][1].x - triangles[i][0].x;
		Number x2 = triangles[i][2].x - triangles[i][0].x;
		Number y1 = triangles[i][1].y - triangles[i][0].y;
		Number y2 = triangles[i][2].y - triangles[i][0].y;


		Number myArea  = (x1*y2 - x2*y1) / 2;
		if (myArea < 0) {
			myArea = Number(0)-myArea;
		}

		// cerr << "Area of triangle #" << i + 1 << " is " << myArea.getDouble() << endl; 

		areaCoveredByTriangles += myArea;
	}
	
	if (fabs((areaCoveredByTriangles - Number(X)*Y).getDouble()) > 0.25) {
		cout << "Triangles do not cover the entire area of the sail. sail area = " << X * Y << ", triangles = " << areaCoveredByTriangles.getDouble() << endl;
		cerr << "Not fully covered" << endl;
		exit(1);
	}

	if (!in) {
		cerr << "invalid infile" << endl;
		exit(1);
	}


	for (i = 0; i < N; i++) {
		out >> x >> y ;
		if (!out) {
			cout << "0" << endl 
				<< "outfile too short or does not contain numbers" << endl;
			cerr << "Syntax error" << endl;
			return 1;
		}
		Number A = x, B = y;	
		A -= triangles[i][0].x;
		B -= triangles[i][0].y;
		triangles[i][0].x += A; triangles[i][0].y += B;
		triangles[i][1].x += A; triangles[i][1].y += B;
		triangles[i][2].x += A; triangles[i][2].y += B;
	}

	// check that the points are inside
	for(i = 0; i < N; i++) {
		checkPoint(triangles[i][0], i + 1);
		checkPoint(triangles[i][1], i + 1);
		checkPoint(triangles[i][2], i + 1);
	}

	int j;
	Point isect;
	for (i = 0; i < N; i++) {
		for (j = i + 1; j < N; j++) {
			if (trianglesIntersectInside(
						triangles[i][0],triangles[i][1],triangles[i][2],
						triangles[j][0],triangles[j][1],triangles[j][2],
						isect
						)) {
				cout << 0 << endl << "Triangles #" << (i + 1) 
					<< " and #" << (j+1) << " intersect at (" <<
				   isect.x.getDouble() << "," << isect.y.getDouble()
				   << ")" << endl;
				cerr << "Intersecting triangles" << endl;
				exit (1);
			}
		}
	}

	cout << "Checked OK" << endl;

	return 0;
}

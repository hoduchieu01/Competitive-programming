
using namespace std;

#include <stdlib.h>
#include <iostream>
#include "lib_eval.h"

static Number one(1);


bool segmentsIntersectInside(Point a1, Point b1, Point a2, Point b2, Point &isection) {
	// we solve the following system:
	// a*A1 + (1-a)*B1 = isection = b*A2 + (1-b)*B2 
	// i.e., a(A1-B1) +b(B2-A2) = B2-B1
	
	Number line1[] = {a1.x - b1.x, b2.x - a2.x, b2.x - b1.x};
	Number line2[] = {a1.y - b1.y, b2.y - a2.y, b2.y - b1.y};
	Number* data[] = { line1, line2 };
	Number out[2];

	if (!gauss(data, 2, out)) {
		return false;
	}
	Number a = out[0], b = out[1];

	if (a <= 0 || a >= 1 || b <=0 || b>= 1) {
		return false;
	}

	isection.x = a * a1.x + (one - a) * b1.x;
	isection.y = a * a1.y + (one - a) * b1.y;

	return true;
}

bool segmentsIntersect(Point a1, Point b1, Point a2, Point b2, Point &isection) {
	// we solve the following system:
	// a*A1 + (1-a)*B1 = isection = b*A2 + (1-b)*B2 
	// i.e., a(A1-B1) +b(B2-A2) = B2-B1
	
	Number line1[] = {a1.x - b1.x, b2.x - a2.x, b2.x - b1.x};
	Number line2[] = {a1.y - b1.y, b2.y - a2.y, b2.y - b1.y};
	Number* data[] = { line1, line2 };
	Number out[2];

	if (!gauss(data, 2, out)) {
		return false;
	}
	Number a = out[0], b = out[1];

	if (a < 0 || a > 1 || b <0 || b> 1) {
		return false;
	}

	isection.x = a * a1.x + (one - a) * b1.x;
	isection.y = a * a1.y + (one - a) * b1.y;

	return true;
}


bool isInTriangle(Point X, Point A, Point B, Point C) {
	// we solve the following system: a*A + b*B + (1-a-b)*C = X,
	// i.e., a*(A-C) + b*(B-C) = X-C
	Number line1[] = {A.x-C.x, B.x-C.x, X.x-C.x};
	Number line2[] = {A.y-C.y, B.y-C.y, X.y-C.y};
	Number* data[] = { line1, line2 };

	Number out[2];

	if (!gauss(data, 2, out)) {
		cerr << "Strange" << endl;
		exit(1);
		return false;
	}
	Number a = out[0], b = out[1];

	if (a < 0 || b <0 || a + b > 1) {
		return false;
	}
	return true;
}


bool gauss(Number** matrix, int n, Number* output) {
	for (int j = 0; j < n; j++) {
		for (int i = j; i < n; i++) {
			if (matrix[i][j] != 0) {
				Number* pos = matrix[i];
				matrix[i] = matrix[j];
				matrix[j] = pos;
				goto rootSelected;
			}
		}
rootSelected:
		Number c = matrix[j][j];
		if (c == 0) {
			return false;
		}
		for (int k = j ; k <= n; k++) {
			matrix[j][k] /= c;
		}
		for (int i = 0; i < n; i++) {
			if (i == j) {
				continue;
			}
			Number cc = matrix[i][j];
			matrix[i][j] = 0;
			for (int k = j + 1; k <= n; k++) {
				matrix[i][k] -= cc * matrix[j][k];
			}
		}
	}
	
	for (int i = 0; i < n; i++) {
		output[i] = matrix[i][n];
	}
	
	return true;
}

bool trianglesIntersectInside(Point a1, Point b1, Point c1, Point a2, Point b2, Point c2, Point &isection) {
	Point conflicts[6 + 9];
	int nc = trianglesIntersectInside2(a1, b1, c1, a2, b2,c2, conflicts);

	if (nc <= 0) {
		return false;
	}

	while(!areColinear(conflicts, nc)) {
		nc --;
	}
	nc++;

	Number v = 0; int i;
	for (i = 0; i < nc; i++) {
		v += conflicts[i].x / nc;
	}
	isection.x = v;
	v = 0;
	for (i = 0; i < nc; i++) {
		v += conflicts[i].y / nc;
	}
	isection.y = v;

	return true;
}
int trianglesIntersectInside2(Point a1, Point b1, Point c1, Point a2, Point b2, Point c2, Point *conflicts) {

	int nc = 0;
	Point isect;

	if (isInTriangle(a1,a2,b2,c2)) { conflicts[nc++] = a1; }
	if (isInTriangle(b1,a2,b2,c2)) { conflicts[nc++] = b1; }
	if (isInTriangle(c1,a2,b2,c2)) { conflicts[nc++] = c1; }

	if (isInTriangle(a2,a1,b1,c1)) { conflicts[nc++] = a2; }
	if (isInTriangle(b2,a1,b1,c1)) { conflicts[nc++] = b2; }
	if (isInTriangle(c2,a1,b1,c1)) { conflicts[nc++] = c2; }

	if (segmentsIntersectInside(a1,b1, a2, b2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(c1,b1, a2, b2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(a1,c1, a2, b2, isect)) { conflicts[nc++] = isect; }

	if (segmentsIntersectInside(a1,b1, c2, b2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(c1,b1, c2, b2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(a1,c1, c2, b2, isect)) { conflicts[nc++] = isect; }

	if (segmentsIntersectInside(a1,b1, a2, c2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(c1,b1, a2, c2, isect)) { conflicts[nc++] = isect; }
	if (segmentsIntersectInside(a1,c1, a2, c2, isect)) { conflicts[nc++] = isect; }

	if (areColinear(conflicts, nc)) {
		return 0;
	}

	return nc;

}

bool areColinear(Point* pts, int n) {
	int i;
	if (n <= 2) {
		return true;
	}
	Point a = pts[0];
	for (i = 1; i < n; i++) {
		if (a.x != pts[i].x || a.y != pts[i].y) {
			break;
		}
	}
	if (i >= n) {
		return true;
	}

	Point b = pts[i];

	Number deltaX = b.x - a.x;
	Number deltaY = b.y - a.y;
	bool isx = (deltaX != 0);
	Number delta = isx? deltaX : deltaY;

	for(i++; i < n; i++) {
		Point x = pts[i];
		Number diff = isx ? (x.x - a.x) : (x.y - a.y);
		Number rat = diff / delta;
		if (x.x != a.x + rat * deltaX || x.y != a.y + rat * deltaY) {
			return false;
		}
	}

	return true;
}

#!/usr/bin/perl -w
use strict;

require("gen-util.pl");


# 1x klasicti loupeznici
# 1x vic loupezniku (4), maly soucet (1000)


sub thief {
	my ($width, $height, $parts) = @_;

	my @parts = randomPartition($height, $parts);
	my @triangles;

	#
	#  +--+
	#  |\ |
	#  | \|
	#  +--+

	for my $part (@parts) {
		push @triangles, [0, $$part[1], 0, $$part[1] + $$part[0], $width, $$part[1]];
		push @triangles, [$width, $$part[1], $width, $$part[1] + $$part[0], 0, $$part[1] + $$part[0]];
	}

	return @triangles;
}



sub thieves {
	my ($dsName, $height, $parts, $nThieves) = @_;

	my $dX = int($height/ $nThieves);
	my @triangles;
	for my $i (0..$nThieves-1) {
		my $x = $dX * $i;

		my @tr = thief($dX, $height, $parts);
		push @triangles, map { [$x + $$_[0], $$_[1], $x + $$_[2], $$_[3], $x + $$_[4], $$_[5]]} @tr;

	}

	outputSail($dsName, $dX * $nThieves,$height,\@triangles, 0);
}



thieves("06", 1000_000, 100, 2);
thieves("07", 10_000, 50, 3);


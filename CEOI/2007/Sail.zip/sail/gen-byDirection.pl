#!/usr/bin/perl -w
use strict;
require("gen-util.pl");

#  n�kolik takovych, ze v�echny trojuhelniky jsou zleva doprava (proste
#    reze se bud shora dolu nebo zleva doprava), mezi nimi
#    * ka�d� rez ma jiny sklon, takze prohledanim do hl/sirky dostanu
#     vysledek rychle
#    * nektere rezy jsou vicekrat, ale ne mnoho, aby dobehl i backtrack
#  jedno z vyse uvedenych, ale ve vice sloupcich (jeden sloupec sirka x,
#   druhy y, treti z, v kazdem to ma tu vlastnost BT nebo exact, nav�c
#   rovnice ax + by + cz = x+y+z ma jedine reseni 1,1,1, at nezavahaji O:-)


sub makeExactPart {
	my ($length, $parts) = @_;
	my $center = $length / $parts;

	my %used;
	my $sum = 0;
	while ($sum < $length) {
		my $x = int (rand(2*$center)) + 1;
		next if $used{$x};
		$sum += $x;
        $used{$x} = 1;
	}

	my @ret = shuffle(keys %used);
	return makeExactPart($length, $parts) unless @ret > $parts / 2 and @ret < 1.5 * $parts;

	@ret;

}

sub genTriangles {
	my ($width, $height, $parts, $allowDuplicates) = @_;
	my ($leftH, $rightH) = (0, 0);

	my %deltaUsed;
	my @triangles;

	for my $delta(@$parts) {
		# $delta is the difference between heights of the newly created points;
		my $allows = 0;
		$allows |= 1 if $rightH + $delta > $leftH and $rightH + $delta <= $height ;
		$allows |= 2 if $leftH + $delta > $rightH and $leftH + $delta <= $height;

		next if $allows == 0;
		$allows = 1 + int(rand(2)) if $allows == 3;

		if ($allows == 1) {
			
			push @triangles, [0, $leftH, 0, $rightH + $delta, $width, $rightH];
			$leftH = $rightH + $delta;
			$deltaUsed{$delta} = 1;

		} elsif ($allows == 2) {
			push @triangles, [0, $leftH, $width, $leftH + $delta, $width, $rightH];
			$rightH = $leftH + $delta;
			$delta = -$delta;
			$deltaUsed{$delta} = 1;
		} else {
			die "something fishy.";
		}
	}

	%deltaUsed = () if $allowDuplicates;

	if ($leftH != $height) {
		my $delta = $height - $rightH; # notice that this is zero $rightH == $height only
		return () if $deltaUsed{$delta};
		push @triangles, [0, $leftH, 0, $height, $width, $rightH];
		$leftH = $height;
	}

	if ($rightH != $height) {
		# we are creating edge with delta 0, so no need to check anything
		push @triangles, [0, $leftH, $width, $height, $width, $rightH];
		$leftH = $height;
	}

	return @triangles;
}

#### really exact

my ($x, $y) = (10_000,100_000);

my @triangles;

while (1) {
	my @parts = makeExactPart($y, 200);
	@triangles = genTriangles($x, $y, \@parts, 1);

	next unless @triangles;
	last;
}

outputSail("08", $x,$y,\@triangles, 0);

my @parts = makeExactPart($y, 200);
my @first = @parts[0..5];
push @parts, @first;
push @parts, @first;
@parts = shuffle(@parts);
### now parts contains some repetitions
@triangles = genTriangles($x, $y, \@parts, 1);

outputSail("09", $x,$y,\@triangles, 0);

## three columns
my @widths = (10_000, 20_000, 40_000);
($x, $y) = ($widths[0] + $widths[1] + $widths[2],100_000);

my $shift = 0;
@triangles = ();
for my $width (@widths) {
	@parts = makeExactPart($y, 150);
	my @tr = genTriangles($width, $y, \@parts, 1);
	push @triangles, map {[$shift + $$_[0], $$_[1], $shift + $$_[2], $$_[3], $shift + $$_[4], $$_[5]]} @tr;
	$shift += $width;
}
outputSail("10", $x,$y,\@triangles, 0);


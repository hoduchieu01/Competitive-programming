

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

#include "lib_eval.h"

#define X_ORIGIN 20
#define Y_ORIGIN 830

#define X_WIDTH 555
#define Y_WIDTH 800

using namespace std;

#define MAX_TRIANGLES 10000

int N, X, Y;

Point triangles[MAX_TRIANGLES + 1][3];

ofstream *psFile;


// returns true if the offender is better.
// calculate the vector product of the two vectors current->next and current->offender.
// (in fact, only the third coordinate).
// if it is zero, the direction is the same. if it is negative (***-hand rule), 
// the first vector (current->next) is to the left of the other. i.e., return
// true only if the coordinate is is positive (offender is to the left).
bool isWorseDirection(Point last, Point current, Point next, Point offender) {

	Number ax = next.x - current.x;
	Number ay = next.y - current.y;
	Number bx = offender.x - current.x;
	Number by = offender.y - current.y;

	Number coord = ax*by - ay*bx;
	return coord > 0;
}

int convexHull(Point *inpts, int nIn, Point *outpts) {

	if (nIn < 3 || areColinear(inpts, nIn)) {
		return 0;
	}
	Point start = inpts[0];
	for (int i = 1; i < nIn; i++) {
		if (start.x > inpts[i].x || (start.x == inpts[i].x && start.y > inpts[i].y)) {
			start = inpts[i];
		}
	}
	// ok, we have the leftmost point.
	Point current = start, last = Point(start.x, start.y - 5); // so we have direction facing up
	int count = 0;
	outpts[count++] = current;
	for (; ; ) {
		Point next = inpts[0];
		int i = 0;
		if (next == current) {
			for (i = 1; i < nIn; i++) {
				if (inpts[i] != current) {
					next = inpts[i];
					break;
				}
			}
		}
		if (next == current) {
			cerr << "bug in convexhull" << endl;
		}
		for (i++; i < nIn; i++) {
			if (inpts[i] != current && isWorseDirection(last, current, next, inpts[i])) {
				next = inpts[i];
			}
		}
		if (next == start) {
			return count;
		}
		if (count >= nIn) {
			cerr << "strange bug in convexHull" << endl;
			return count;
		}
		outpts[count++] = next;
		last = current; current = next;
	}
	/* no return from here */
}


Number minX, maxX, step;
Number minY, maxY, yOrigin;

void drawPoint(Point pt) {
	Number x = (pt.x - minX) * step;
	Number y = (pt.y - minY) * step;

	*psFile << (X_ORIGIN + x.getDouble()) << " " << ((yOrigin + y).getDouble());
}

void drawObject(Point *pts, int count, bool doFill) {
	int i;
	if (count < 1) {
		return;
	}
	drawPoint(pts[0]);
	*psFile << " moveto" << endl;
	for (i = 1; i < count; i++) {
		drawPoint(pts[i]);
		*psFile << " lineto" << endl;
	}
	*psFile << "closepath" << endl;
	if (doFill) {
		*psFile << "fill" << endl;
	} else {
		*psFile << "stroke" << endl;
	}
}


Point outSailPts[40];
int nOutSailPts;

void checkSailPts() {
	if (areColinear(outSailPts, nOutSailPts)) {
		return;
	}
	Point hull[40];
	int cnt = convexHull(outSailPts, nOutSailPts, hull);
	if (cnt < 3) {
		cerr << "something fishy in convexHull()" << endl;
		return;
	}
	drawObject(hull, cnt, true);
}

bool okPoint(Point pt) {
	return pt.x >= 0 && pt.x <= X && pt.y >= 0 && pt.y <=Y;
}

void checkTriangleInSail(int idx) {
	Point* t = triangles[idx];
	if (okPoint(t[0]) && okPoint(t[1]) && okPoint(t[2])) {
		return;
	}
	cout << "Triangle #" << (idx + 1) << " lies partly outside the sail" << endl;
	Point line[2];
	Point isect;
	// 1. left to the sail
	nOutSailPts = 0;
	for (int i = 0; i < 3; i++) {if (t[i].x <= 0) {outSailPts[nOutSailPts++] = t[i] ;}}
	line[0] = Point(0, minY);
	line[1] = Point(0, maxY);
	if (segmentsIntersect(line[0], line[1], t[0], t[1], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[0], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[1], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	checkSailPts();
	
	// 2. right to the sail
	nOutSailPts = 0;
	for (int i = 0; i < 3; i++) {if (t[i].x >= X) {outSailPts[nOutSailPts++] = t[i] ;}}
	line[0] = Point(X, minY);
	line[1] = Point(X, maxY);
	if (segmentsIntersect(line[0], line[1], t[0], t[1], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[0], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[1], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	checkSailPts();
	
	// 3. above the sail
	nOutSailPts = 0;
	for (int i = 0; i < 3; i++) {if (t[i].y >= Y) {outSailPts[nOutSailPts++] = t[i] ;}}
	line[0] = Point(minX, Y);
	line[1] = Point(maxX, Y);
	if (segmentsIntersect(line[0], line[1], t[0], t[1], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[0], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[1], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	checkSailPts();
	
	// 4. below the sail
	nOutSailPts = 0;
	for (int i = 0; i < 3; i++) {if (t[i].y <= 0) {outSailPts[nOutSailPts++] = t[i] ;}}
	line[0] = Point(minX, 0);
	line[1] = Point(maxX, 0);
	if (segmentsIntersect(line[0], line[1], t[0], t[1], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[0], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	if (segmentsIntersect(line[0], line[1], t[1], t[2], isect)) { outSailPts[nOutSailPts++] = isect; }
	checkSailPts();
}

void calcBounds() {
	minX = 0;
	minY = 0;
	maxX = X;
	maxY = Y;

	for (int i = 0; i < N; i++) {
		for (int j = 0; j < 3; j++) {
			if (triangles[i][j].x < minX) { minX = triangles[i][j].x; }
			if (triangles[i][j].x > maxX) { maxX = triangles[i][j].x; }
			if (triangles[i][j].y < minY) { minY = triangles[i][j].y; }
			if (triangles[i][j].y > maxY) { maxY = triangles[i][j].y; }
		}
	}

	Number sx = Number(X_WIDTH) / (maxX - minX);
	Number sy = Number(Y_WIDTH) / (maxY - minY);

	if (sx < sy) {
		step = sx;
	} else {
		step = sy;
	}
	yOrigin = Number(Y_ORIGIN) - (maxY - minY) * step;
}



void usage(char* progname) {
	cerr << "Usage is: " << endl
		<< "   " << progname << " infile outfile\t\t\tto see the sail picture via gv" << endl
		<< "   " << progname << " -o psfile infile outfile\t\tto generate ps file only " << endl;

	exit(1);
}

int main(int argc, char** argv) {
	if (argc != 3 && (argc != 5 || strcmp(argv[1], "-o"))) {
		usage(argv[0]);
	}

	bool doShow = (argc == 3);
	char *psFileName;
	if (doShow) {
		psFileName = "/tmp/sail-tmp.ps";
	} else {
		psFileName = argv[2];
		argv = argv + 2;
	}


	ifstream in(argv[1]); 
	ifstream out(argv[2]); 

	in >> N >> X >> Y;
	if (!in) {
		cerr << "invalid infile" << endl;
		exit(1);
	}

	Number areaCoveredByTriangles = 0;

	int i, x, y;
	for (i = 0; i < N; i++) {
		in >> x >> y; triangles[i][0] = Point(x, y);
		in >> x >> y; triangles[i][1] = Point(x, y);
		in >> x >> y; triangles[i][2] = Point(x, y);

		if (areColinear(triangles[i], 3)) {
			cerr << "Triangle #" << (i+1) << " is not a triangle" << endl;
			exit(1);
		}
		
		Number x1 = triangles[i][1].x - triangles[i][0].x;
		Number x2 = triangles[i][2].x - triangles[i][0].x;
		Number y1 = triangles[i][1].y - triangles[i][0].y;
		Number y2 = triangles[i][2].y - triangles[i][0].y;


		Number myArea  = (x1*y2 - x2*y1) / 2;
		if (myArea < 0) {
			myArea = Number(0)-myArea;
		}

		// cerr << "Area of triangle #" << i + 1 << " is " << myArea.getDouble() << endl; 

		areaCoveredByTriangles += myArea;
	}
	
	if (fabs((areaCoveredByTriangles - Number(X)*Y).getDouble()) > 0.25) {
		cerr << "Triangles do not cover the entire area of the sail. sail area = " << X * Y << ", triangles = " << areaCoveredByTriangles.getDouble() << endl;
		exit(1);
	}

	if (!in) {
		cerr << "invalid infile" << endl;
		exit(1);
	}


	for (i = 0; i < N; i++) {
		out >> x >> y ;
		if (!out) {
			cout << "outfile too short or does not contain numbers" << endl;
			return 0;
		}
		Number A = x, B = y;	
		A -= triangles[i][0].x;
		B -= triangles[i][0].y;
		triangles[i][0].x += A; triangles[i][0].y += B;
		triangles[i][1].x += A; triangles[i][1].y += B;
		triangles[i][2].x += A; triangles[i][2].y += B;
	}
	
	calcBounds();


	ofstream ps(psFileName);

	if (!ps) {
		cerr << "failed to open " << psFileName << "for writing" << endl;
		exit(1);
	}

	psFile = &ps;
	*psFile << "%!PS-Adobe-2.0" << endl;
	*psFile << "%%Pages: 1" << endl;
	*psFile << "%%EndComments" << endl;
	*psFile << "%%BeginDocument" << endl;
	*psFile << "%%Page: 1 1" << endl;
	*psFile << "0.2 setlinewidth" << endl;
	*psFile << "255 0 0 setrgbcolor" << endl;

	Point sail[4] = {Point(0,0), Point(0, Y), Point(X,Y), Point(X, 0)};
	drawObject(sail, 4, true);

	*psFile << "255 255 255 setrgbcolor" << endl;

	for (i = 0; i < N; i++) {
		drawObject(triangles[i], 3, true);
	}

	*psFile << "0 255 0 setrgbcolor" << endl;

	// check that the points are inside
	for(i = 0; i < N; i++) {
		checkTriangleInSail(i);
	}

	*psFile << "0 0 255 setrgbcolor" << endl;

	int j;
	int count;
	Point tmp[40];
	Point hull[40];
	for (i = 0; i < N; i++) {
		for (j = i + 1; j < N; j++) {
			if ((count = trianglesIntersectInside2(
						triangles[i][0],triangles[i][1],triangles[i][2],
						triangles[j][0],triangles[j][1],triangles[j][2],
						tmp
						)) > 0) {

				count = convexHull(tmp, count, hull);
				if (count < 3) {
					cerr << "cannot happen!" << endl;
					continue;
				}
				drawObject(hull, count, true);
				cout << "Triangles #" << (i + 1) 
					<< " and #" << (j+1) << " intersect." << endl;
			}
		}
	}

	*psFile << "0 0 0 setrgbcolor" << endl;

	for (i = 0; i < N; i++) {
		drawObject(triangles[i], 3, false);
	}

	drawObject(sail, 4, false);

	*psFile << "showpage" << endl;
	*psFile << "%%EndDocument" << endl;
	*psFile << "%%Trailer" << endl;
	*psFile << "%%EOF" << endl;
	psFile->flush();
	psFile->close();

	if (doShow) {
		execlp("gv", "gv", psFileName, NULL);
		perror ("exec gv failed!");
		return 1;
	}

	return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#define ADD 101
#define SUB 102
#define MUL 103
#define X_VALUE 104

#define MAXB 36
#define MAX_TOK 100000
#define BUFSIZE (MAX_TOK + 10)

int B;

int expr[MAX_TOK + 10];
int exprLen;
int stack[MAX_TOK + 10];

FILE *in, *out;



int digitToInt(char c) {
	int val;
	if (c >= '0' && c <= '9') {
		val = c - '0';
	} else if (c >= 'A' && c <= 'Z') {
		val = 10 + (c - 'A');
	} else {
		fprintf(stderr, "Invalid character '%c' in digit conversion\n", c);
		val = -1;
		exit(1);
	}
	if (val >= B) {
		fprintf(stderr, 
				"Character '%c' is an invalid digit in a base %d number\n",
			   	c, B);
		exit(1);
	}
	return val;
}

char intToDigit(int v) {
	if (v < 0 || v >= B) {
		fprintf(stderr, "There is no digit for %d in a base %d system\n", v, B);
		exit(1);
	}
	if (v < 10) {
		return '0' + v;
	} else {
		return 'A' + (v - 10);
	}
}


void readInput(char *input) {
	exprLen = 0;
	for(; *input && *input != '\n'; input++) {
		if (*input == ' ') {
			continue;
		}
		if (*input == '+') {
			expr[exprLen++] = ADD;
		} else if (*input == '-') {
			expr[exprLen++] = SUB;
		} else if (*input == '*') {
			expr[exprLen++] = MUL;
		} else if (*input == 'x') {
			expr[exprLen++] = X_VALUE;
		} else if (isalnum(*input)) {
			while(isalnum(*input)) {
				input++;
			}
			input--;
			/* we now have the last digit */
			expr[exprLen++] = digitToInt(*input);
		} else {
			fprintf(stderr, "Invalid character %c in expression\n", *input);
			exit(1);
		}
	}
}

int evalInput(int x) {
	int sp = 0, i;
	for (i = 0; i < exprLen; i++) {
		int instr = expr[i];
		if (instr < 100) {
			stack[sp++] = instr;
		} else if (instr == X_VALUE) {
			stack[sp++] = x;
		} else {
			int a, b, v = -1;
			if (sp < 2) {
				fprintf(stderr, "Stack underflow at %dth command!\n", i);
				exit(1);
			}
			/* pop 2 values */
			b = stack[sp - 1];
			a = stack[sp - 2];
			sp -=2;
			switch(instr) {
				case ADD: v = a + b; break;
				case SUB: v = B + a - b; break;
				case MUL: v = a * b; break;
				default: 
						  fprintf(stderr, "Unknown command %d\n", instr);
						  exit(1);
						  break;
			}
			v = v % B;
			if (v < 0) {
				fprintf(stderr, "Something fishy down there\n");
				exit(1);
			}
			/* push the result */
			stack[sp ++] = v;
		}
	} /* end for */
	if (sp != 1) {
		fprintf(stderr, "Expression did not finish with one-element stack!\n");
		exit(1);
	}
	return stack[0];
}

int main() {

	char line[BUFSIZE + 2];
	int x, i, N;
	int values[MAXB + 1];

	in = stdin;
	fgets(line, BUFSIZE, in);
	sscanf(line, "%d%d", &B, &N);
	fgets(line, BUFSIZE, in);
	readInput(line);
	for (x = 0; x < B; x++) {
		values[x] = evalInput(x);
	}

	out = stdout;

	for (i = 0; i < N; i++) {
		char *c;
		fgets(line, BUFSIZE, in);
		c = line;
		while (isalnum(*c)) {
			c++;
		}
		c--;
		/* c now points to the last alphanumeric character */
		x = digitToInt(*c);
		fprintf(out, "%c\n", intToDigit(values[x]));
	}

	fflush(out);

	return 0;
}

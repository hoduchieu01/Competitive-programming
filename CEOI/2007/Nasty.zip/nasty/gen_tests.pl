#!/usr/bin/perl -w

use strict;

open OUT, ">nasty0.in" || die "open";
print OUT "15 4\n2 x * 123A +\n1\n2\n3\n4\n";


sub genValue {
	my ($b, $x) = @_;

	my $val;
	if (defined $x) {
		$val = int(rand($b + 1));
	} else {
		$val = int(rand($b));
	}
	return $x if $val == $b;

	return chr ($val + ord('0')) if $val <= 9;
	return chr ($val - 10 + ord('A'));
}

sub genData {
	my($num, $exprLen, $valLen, $b, $rops, $x, $pOper) = @_;

	my @ops = @$rops;

	my $expr = "" . genValue($b, $x);
	my $depth = 0;  #actually, depth - 1

	while (length($expr) + 2 * $depth + 4 < $exprLen) {
		if ($depth >= 1 and rand() < $pOper) {
			$depth--;
			$expr .= " " . $ops[int(rand(scalar(@ops)))];
		} else {
			$expr .= " " . genValue($b, $x);
			$depth++;
		}
	}

	for my $x (1..$depth) {
		$expr .= " " . $ops[int(rand(scalar(@ops)))];
	}

	die "expr too long"  unless length($expr) <= $exprLen;

	open OUT, ">nasty$num.in" || die "open";
	print OUT "$b $valLen\n";
	print OUT "$expr\n";

	for my $x (1..$valLen) {
		print OUT genValue($b) . "\n";
	}
	
	close OUT || die "close";

}

my $stdPOper = 0.45;

genData(     "1",   1000,    100, 10, [qw(+ * )], "x", $stdPOper);
genData(     "2",  10000,   1000,  2, [qw(+ * )], "x", $stdPOper);
genData(     "3", 100000,   1000, 18,   [qw(+ )], "x", $stdPOper);
#no x at all
genData(     "4",  10000,   1000, 10, [qw(+ * )], undef, $stdPOper);
genData(     "5",   1000,  10000, 12, [qw(+ * )], "x", $stdPOper);
genData(     "6",  10000,  10000, 36, [qw(+ * )], "x", $stdPOper);
genData(     "7", 100000,  10000, 28, [qw(+ * )], "x", $stdPOper);
genData(     "8", 100000, 100000, 10, [qw(+ * )], "x", $stdPOper);
# no stack
genData(     "9", 100000, 100000, 31, [qw(+ * )], "x", 1);
#max stack
genData(    "10", 100000, 100000, 10, [qw(+ * )], "x", 0);



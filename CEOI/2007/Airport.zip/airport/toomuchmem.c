
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

struct perf_t {
	unsigned len;
	struct ins {
		enum type {
			unlock = 0,
			lock = 1
		} type;
		unsigned lock;
	} *inss;
} perfs[ 2 ];

typedef unsigned char *lockstate_t;

struct pos_t {
	unsigned char reachable;
	unsigned char prev;
	lockstate_t state;
} *pos;

unsigned lockcnt;

void readseq( unsigned char index) {
        unsigned i;

	scanf("%u ", &perfs[ index ].len );
	perfs[ index ].inss = malloc( perfs[ index ].len * sizeof *perfs[ index ].inss );
	for(i = 0; i < perfs[ index ].len; ++i ) {
		char c[4];
		scanf("%s %u ", c, &perfs[ index ].inss[ i ].lock );
		perfs[ index ].inss[ i ].lock --;
		perfs[ index ].inss[ i ].type = ( c[2] == 'S' );
	}
}

unsigned pind( unsigned i, unsigned j ) {
	return( i * perfs[ 1 ].len + j );
}

void checkdead( unsigned i, unsigned j ) {
	if( ( i == perfs[ 0 ].len ) || ( j == perfs[ 1 ].len ) )//At the end
		return;
	if( perfs[ 0 ].inss[ i ].type && pos[ pind( i, j ) ].state[ perfs[ 0 ].inss[ i ].lock ] &&
		perfs[ 1 ].inss[ j ].type && pos[ pind( i, j ) ].state[ perfs[ 1 ].inss[ j ].lock ] ) {//deadlock, rocenstruct how we got here
		char result[ perfs[ 0 ].len + perfs[ 1 ].len + 1 ], *r = result + perfs[ 0 ].len + perfs[ 1 ].len;
		*r = 0;
		while( pos[ pind( i, j ) ].prev != 2 ) {
			*( -- r ) = pos[ pind( i, j ) ].prev + '1';
			if( pos[ pind( i, j ) ].prev == 0 )
				i --;
			else
				j --;
		}
		printf( "%s\n", r );
		exit( 0 );
	}
}

int main( int argc, char *argv[] ) {
        unsigned i,j;

	//Read the input
	scanf("%u ", &lockcnt );
	readseq( 0);
	readseq( 1);
	//Prepare the states
	pos = malloc( ( perfs[ 0 ].len + 1 ) * ( perfs[ 1 ].len + 1 ) * sizeof *pos );
	//The position where none have run is reachable, nothing locked
	pos[ pind( 0, 0 ) ].reachable = 1;
	pos[ pind( 0, 0 ) ].prev = 2;
	unsigned statesize = lockcnt * sizeof *pos->state;
	pos[ pind( 0, 0 ) ].state = malloc( statesize );
	memset( pos[ pind( 0, 0 ) ].state, 0, statesize );
	//Count all reachable places
	for(i = 0; i <= perfs[ 0 ].len; ++ i ) for(j = 0; j <= perfs[ 1 ].len; j ++ ) {
		if( !i && !j )
			continue;
		if( i && pos[ pind( i - 1, j ) ].reachable && ( ( perfs[ 0 ].inss[ i - 1 ].type == unlock ) || ! pos[ pind( i - 1, j ) ].state[ perfs[ 0 ].inss[ i - 1 ].lock ] ) ) {//Is it reachable by the A command?
			pos[ pind( i, j ) ].reachable = 1;
			pos[ pind( i, j ) ].prev = 0;
			pos[ pind( i, j ) ].state = malloc( statesize );
			memcpy( pos[ pind( i, j ) ].state, pos[ pind( i - 1, j ) ].state, statesize );
			pos[ pind( i, j ) ].state[ perfs[ 0 ].inss[ i - 1 ].lock ] = perfs[ 0 ].inss[ i - 1 ].type;
		} else if( j && pos[ pind( i, j - 1 ) ].reachable && ( ( perfs[ 1 ].inss[ j - 1 ].type == unlock ) || ! pos[ pind( i, j - 1 ) ].state[ perfs[ 1 ].inss[ j - 1 ].lock ] ) ) {//Reachable by the B command
			pos[ pind( i, j ) ].reachable = 1;
			pos[ pind( i, j ) ].prev = 1;
			pos[ pind( i, j ) ].state = malloc( statesize );
			memcpy( pos[ pind( i, j ) ].state, pos[ pind( i, j - 1 ) ].state, statesize );
			pos[ pind( i, j ) ].state[ perfs[ 1 ].inss[ j - 1 ].lock ] = perfs[ 1 ].inss[ j - 1 ].type;
		} else
			pos[ pind( i, j ) ].reachable = 0;
		if( pos[ pind( i, j ) ].reachable )
			checkdead( i, j );
	}
	printf("The performances will always finish.\n" );
	return( 0 );
}

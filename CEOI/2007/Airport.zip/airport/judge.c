
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define end( result ) { fclose( output ); fclose( expected ); return( result ); }

struct {
	int cnt;
	struct {
		enum {
			unlock = 0,
			lock = 1
		} type;
		int index;
	} *steps;
} seqs[ 2 ];

void readseq( FILE *f, int s ) {
	fscanf( f, " %d", &seqs[ s ].cnt );
	seqs[ s ].steps = malloc( seqs[ s ].cnt * sizeof *seqs[ s ].steps );
	for( int i = 0; i < seqs[ s ].cnt; ++ i ) {
		char type[4];
		fscanf( f, "%s %d", type, &seqs[ s ].steps[ i ].index );
		seqs[ s ].steps[ i ].index--;
		seqs[ s ].steps[ i ].type = ( type[2] == 'S' );
	}
}

int main( int argc, char *argv[] ) {
	if( argc < 4 ) {
		fprintf( stderr, "airjudge output expected input\n" );
		return 2;
	}
	FILE *output = fopen( argv[ 1 ], "rt" );
	FILE *expected = fopen( argv[ 2 ], "rt" );
	int deadlock;
	fscanf( expected, "%d", &deadlock );
	if( deadlock ) {
		FILE *input = fopen( argv[ 3 ], "rt" );
		int run_cnt;
		fscanf( input, "%d", &run_cnt );
		char *runways = malloc( run_cnt * sizeof *runways );
		memset( runways, 0, run_cnt * sizeof *runways );
		readseq( input, 0 );
		readseq( input, 1 );
		fclose( input );
		int pos[ 2 ] = { 0, 0 };
		char inp;
		while( ( inp = fgetc( output ) ) != EOF ) {
			int seqi;
			if( inp == '1' )
				seqi = 0;
			else if( inp == '2' )
				seqi = 1;
			else
				continue; /*Something else - like space, do not care */
			if( pos[ seqi ] >= seqs[ seqi ].cnt ) {
				fprintf( stderr, "No more actions in the sequence\n" );
				end( 1 );
			}
			if( runways[ seqs[ seqi ].steps[ pos[ seqi ] ].index ] && seqs[ seqi ].steps[ pos[ seqi ] ].type ) {
				printf( "That one is already locked (%d, %d)\n", pos[0]+1, pos[1]+1 );
				fprintf( stderr, "Already locked\n");
				end( 1 );
			}
			runways[ seqs[ seqi ].steps[ pos[ seqi ] ].index ] = seqs[ seqi ].steps[ pos[ seqi ] ].type;
			pos[ seqi ] ++;
		}
		if( ( pos[ 0 ] == seqs[ 0 ].cnt ) || ( pos[ 1 ] == seqs[ 1 ].cnt ) ) {
			fprintf( stderr, "Run out of sequence\n" );
			end( 1 );
		}
		if( ( seqs[ 0 ].steps[ pos[ 0 ] ].type ) && ( runways[ seqs[ 0 ].steps[ pos[ 0 ] ].index ] ) &&
			( seqs[ 0 ].steps[ pos[ 0 ] ].type ) && ( runways[ seqs[ 0 ].steps[ pos[ 0 ] ].index ] ) ) {
			end( 0 );
		} else {
			fprintf( stderr, "Not a deadlock\n" );
			end( 1 );
		}
	} else {
		char result[ 100 ];
		fgets( result, 100, output );
		if( strlen( result ) && ( result[ strlen( result ) - 1 ] == '\n' ) )
			result[ strlen( result ) - 1 ] = '\0';
		if( strcmp( "The performances will always finish.", result ) == 0 ) {
			end( 0 );
		} else {
			fprintf( stderr, "False alarm\n" );
			end( 1 );
		}
	}
}

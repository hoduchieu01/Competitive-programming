#include <stdio.h>
#include <stdlib.h>

#undef HASH

#define MAX 1000000

int N;

struct vertex {
  struct vertex *parent, *son[3];
  int depth;
  unsigned char deg;
  unsigned char seen;
#ifdef HASH
  unsigned int hash;
#endif
} v[MAX+1];

struct vertex *order[MAX];
int first[MAX+2];

#if 1
#define ASSERT(x) do { if (!(x)) { fprintf(stderr, "Assertion " #x " failed\n"); abort(); } } while(0)
#else
#define ASSERT(x) do { } while(0)
#endif

#if 0
#define DBG(x...) fprintf(stderr, x)
#else
#define DBG(x...) do { } while(0)
#endif

void rd(void)
{
  struct vertex *p = v;
  int c;
  while ((c = getchar()) != '\n')
    if (c == '(')
      {
	struct vertex *q = &v[++N];
	ASSERT(N <= MAX);
	q->parent = p;
	ASSERT(p->deg < 3);
	p->son[p->deg++] = q;
	p = q;
      }
    else if (c == ')')
      {
	p->depth = 1;
	for (int i=0; i<p->deg; i++)
	  if (p->son[i]->depth >= p->depth)
	    p->depth = p->son[i]->depth + 1;
	p = p->parent;
	ASSERT(p);
      }
    else
      ASSERT(0);
  ASSERT(p == v);
  DBG("Read tree with N=%d, depth=%d\n", N, v[1].depth);
}

void ibfs(void)
{
  int cnt = 0;
  for (int i=1; i<=N; i++)
    if (v[i].depth == 1)
      order[cnt++] = &v[i];
  first[2] = cnt;

  for (int i=1; first[i] < first[i+1]; i++)
    {
      DBG("Depth %d: %d vertices\n", i, first[i+1]-first[i]);
      for (int j=first[i]; j < first[i+1]; j++)
	if (order[j]->parent->depth == order[j]->depth + 1 && !order[j]->parent->seen)
	  {
	    order[cnt++] = order[j]->parent;
	    order[j]->parent->seen = 1;
	  }
      first[i+2] = cnt;
    }
}

int rcmp(struct vertex *a, struct vertex *b)
{
#ifdef HASH
  if (a->hash < b->hash)
    return -1;
  if (a->hash > b->hash)
    return 1;
#endif
  if (a->deg < b->deg)
    return -1;
  if (a->deg > b->deg)
    return 1;
  if (a->depth < b->depth)
    return -1;
  if (a->depth > b->depth)
    return 1;
  for (int i=0; i<a->deg; i++)
    {
      int res = rcmp(a->son[i], b->son[i]);
      if (res)
	return res;
    }
  return 0;
}

int cmp(const void *A, const void *B)
{
  struct vertex * const *AA = A, * const *BB = B;
  struct vertex *a = *AA, *b = *BB;
  return rcmp(a, b);
}

void identify(void)
{
  for (int d=1; first[d] < first[d+1]; d++)
    {
      for (int i=first[d]; i<first[d+1]; i++)
	{
	  struct vertex *v = order[i];
	  for (int j=v->deg-1; j>=0; j--)
	    for (int k=0; k<j; k++)
	      if (cmp(&v->son[k], &v->son[k+1]) > 0)
		{
		  struct vertex *w = v->son[k];
		  v->son[k] = v->son[k+1];
		  v->son[k+1] = w;
		}
#ifdef HASH
	  v->hash = v->deg;
	  for (int j=0; j<v->deg; j++)
	    v->hash = v->hash * 259309 + v->son[j]->hash;
#endif
	}
      qsort(order + first[d], first[d+1] - first[d], sizeof(order[0]), cmp);
      int eqcnt = 1;
      for (int i=first[d]+1; i < first[d+1]; i++)
	if (cmp(&order[i-1], &order[i]))
	  eqcnt++;
      printf("%d\n", eqcnt);
    }
}

int main(void)
{
  rd();
  ibfs();
  identify();
  return 0;
}

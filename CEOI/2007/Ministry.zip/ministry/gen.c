#include <stdio.h>
#include <stdlib.h>

#define S(x) puts(#x); f = fopen(#x ".in", "w")
#define E() fputc('\n', f); fclose(f)

FILE *f;

void regular(int deg, int N)
{
  if (N < 1)
    return;
  N--;
  int n = N/deg;
  fputc('(', f);
  for (int i=0; i<deg; i++)
    regular(deg, n + (i ? 0 : N%deg));
  fputc(')', f);
}

void rnd(int N, int limit)
{
  if (N < limit)
    {
      for (int i=0; i<N; i++)
	fputc('(', f);
      for (int i=0; i<N; i++)
	fputc(')', f);
      return;
    }
  N--;
  int deg = 1 + random() % 3;
  int n = N/deg;
  fputc('(', f);
  for (int i=0; i<deg; i++)
    rnd(n + (i ? 0 : N%deg), limit);
  fputc(')', f);
}

struct vertex {
  int son[3];
  int n;
} noniso[1000000];
int first[100];

void gen_noniso(void)
{
  int cnt = 1;
  first[1] = cnt;
  for (int n=1; n<=12; n++)
    {
      for (int i=0; i<first[n]; i++)
	for (int j=i; j<first[n]; j++)
	  for (int k=j; k<first[n]; k++)
	    if (noniso[i].n + noniso[j].n + noniso[k].n == n-1)
	      {
		noniso[cnt] = (struct vertex) { .son = { i, j, k }, .n = n };
		cnt++;
	      }
      first[n+1] = cnt;
      // printf("Noniso: %d for n=%d\n", first[n+1] - first[n], n);
    }
}

void show(int i)
{
  if (!i)
    return;
  fputc('(', f);
  for (int j=0; j<3; j++)
    show(noniso[i].son[j]);
  fputc(')', f);
}

void combi(int N)
{
  if (N <= 100)
    {
      int open = 0;		// Attach the snake
      while (N > 12)
	{
	  fputc('(', f);
	  open++;
	  N--;
	}
#if 0
      int i = first[N] + random() % (first[N+1] - first[N]);
#else
      static int cnt[100];
      int i = first[N] + cnt[N];
      cnt[N] = (cnt[N]+1) % (first[N+1] - first[N]);
#endif
      show(i);
      while (open--)
	fputc(')', f);
      return;
    }
  N--;
  // int deg = 1 + random() % 3;
  int deg = 3;
  int n = N/deg;
  fputc('(', f);
  for (int i=0; i<deg; i++)
    combi(n + (i ? 0 : N%deg));
  fputc(')', f);
}

void snake(int n)
{
  for (int i=0; i<n; i++)
    fputc('(', f);
  for (int i=0; i<n; i++)
    fputc(')', f);
}

void centipede(int n)
{
  for (int i=0; i<n/2; i++)
    {
      fputc('(', f);
      fputc('(', f);
      fputc(')', f);
    }
  for (int i=0; i<n/2; i++)
    fputc(')', f);
}

int main(void)
{
  S(1);
  regular(3, 100);
  E();

  S(2);
  centipede(100);
  E();

  S(3);
  srand(42);
  rnd(1000, 1);
  E();

  S(4);
  snake(10000);
  E();

  S(5);
  centipede(100000);
  E();

  S(6);
  srand(424);
  rnd(100000, 30);
  E();

  S(7);
  srand(4242);
  rnd(500000, 555);
  E();

  S(8);
  srand(42424);
  rnd(1000000, 1000);
  E();

  S(9);
  regular(2, 1000000);
  E();

  S(10);
  srand(424242);
  gen_noniso();
  combi(1000000);
  E();

  return 0;
}

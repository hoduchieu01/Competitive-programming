#include <stdio.h>
#include <string.h>

void get(char *s, FILE *f)
{
	int i=0, c;
	while ((c = fgetc(f)) >= 0 && c != '\n')
		if (i < 4095)
			s[i++] = c;
	s[i] = 0;
	while (i > 0 && (s[i-1] == '\r' || s[i-1] == ' ' || s[i-1] == '\t'))
		s[--i] = 0;
}

int main(int argc, char **argv)
{
	char a1[4096], a2[4096], b1[4096], b2[4096];

	if (argc != 4) {
		fprintf(stderr, "usage: judge <out> <correct-out> <pts>\n");
		return 1;
	}

	FILE *out = fopen(argv[1], "r");
	if (!out) return 10;
	get(a1, out);
	get(a2, out);
	if (fgetc(out) >= 0) {
		fprintf(stderr, "Garbage after end\n");
		return 1;
	}
	fclose(out);

	FILE *ok = fopen(argv[2], "r");
	if (!ok) return 11;
	get(b1, ok);
	get(b2, ok);
	fclose(ok);

	int points;
	if (!strcmp(a1, b1) && !strcmp(a2, b2))
		points = 5;
	else {
		printf("Output differs:\n");
		printf("-%s\n-%s\n", b1, b2);
		printf("+%s\n+%s\n", a1, a2);
		if (strcmp(a1, b1) && strcmp(a2, b2)) {
			fprintf(stderr, "Wrong answer\n");
			return 1;
		}
		points = 2;
		printf("Partially correct answer\n");
	}

	FILE *pts = fopen(argv[3], "w");
	fprintf(pts, "%d\n", points);
	fclose(pts);
	return 0;
}
